(function() {
	angular.module("ajudeMais.utils", ['ui.bootstrap']);
})();