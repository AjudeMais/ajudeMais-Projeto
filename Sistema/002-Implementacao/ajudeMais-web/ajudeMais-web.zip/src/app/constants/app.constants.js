(function () {
    angular.module('amApp')
        .constant('Api', "http://localhost:8080")
;
})();
