(function () {
    angular.module('layout', ['toastr', 'angular-loading-bar']);
})();